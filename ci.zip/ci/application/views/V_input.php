<!DOCTYPE html>
<html>
<head>
	<title>Praktikum</title>
</head>
<body>
	<h2>Data Mahasiswa</h2>
	<form action="<?php echo site_url('C_mahasiswa/insert'); ?>" method="POST">
		<input type="text" name="nim" placeholder="nim">
		<input type="text" name="nama" placeholder="nama">
		<input type="text" name="angkatan" placeholder="angkatan">
		<button type="sumbit">Tambah Data</button>
	</form>
	<br>
	<br>
	<table border="1">
	<thead>
		<tr>
			<th>NIM</th>
			<th>Nama</th>
			<th>Angkatan</th>
			<th>Action</th>
		</tr>
	</thead>

	<tbody>
		<?php
			foreach ($mahasiswa as $key) {			
		?>
		<tr>
			<th><?php echo $key-> nim;?></th>
			<th><?php echo $key-> nama;?></th>
			<th><?php echo $key-> angkatan;?></th>
			<th> <a href="">Edit</a></th>
			<th><a href="">Delete</a></th>
		</tr>
		<?php
		}
		?>
	</tbody>
	</table>	
</body>
</html>