<?php
/**
 * 
 */
class M_mahasiswa extends CI_model
{
	
	function __construct()
	{
		parent::__construct();
	}
	function selectAll(){
		$this->db->select('*');
		$this->db->from('data_mhs');
		return $this->db->get();
	}
	function insert($data){
		$this->db->insert('data_mhs',$data);
	}
}

?>