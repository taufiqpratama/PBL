<?php
/**
 * 
 */
class C_mahasiswa extends CI_Controller
{
	
	public function index()
	{
		$data['mahasiswa'] = $this->M_mahasiswa->selectAll();
		$this->load->view('V_input');
	}
	public function insert(){
		$data['nim'] = $this-> input -> post('nim');
		$data['nama'] = $this-> input -> post('nama');
		$data['angkatan'] = $this-> input -> post('angkatan');

		$this->M_mahasiswa->insert($data);

		$this->load->view('V_input');
	}
}
?>
